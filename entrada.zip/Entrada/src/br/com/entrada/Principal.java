package br.com.entrada;

//importar a classe Scanner

import java.util.Scanner;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciar o objeto de classe Pessoa
		
		Pessoa gente = new Pessoa ();
		
		//instanciar o objeto da classe Scanner 
		
		Scanner leia = new Scanner (System.in);
		
		
		//repassar os valores dos atributos
		
		System.out.println("Informe seu nome: " );
		gente.nome = leia.nextLine();
		System.out.println("Informe sua Idade: ");
		gente.idade = leia.nextInt();
		
		//Fazer limpeza de buffer
		
		leia.nextLine();
		
		
		System.out.println("Informe o seu genero: ");
		gente.genero = leia.nextLine();
		System.out.println("Informe sua nacionalidade: ");
		gente.nacionalidade = leia.nextLine();
		
		//Imprimir os dados na tela
		gente.apresentar ();
		
		
		
		
		

	}

}
