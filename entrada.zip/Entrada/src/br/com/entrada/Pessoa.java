package br.com.entrada;

public class Pessoa {
//atributos
	public String nome;
	public String genero;
	public String nacionalidade;
	public int idade;
	
	//m�todo
	public void apresentar() {
		System.out.println("Ol�! meu nome � " + this.nome + ".");
		System.out.println("Sou do genero: " + this.genero + ".");
		System.out.println("Sou "+ this.nacionalidade + ".");
		System.out.println("E tenho:  "+ this.idade + " anos.");
	}
}
