package br.com.encontro;

public class Praca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//instanciar os objetos da classe pessoa
	Pessoa homem = new Pessoa ();
	Pessoa mulher = new Pessoa ();
	
	//astribuir valores aos objetos
	
	homem.nome = "Jo�o Batista";
	homem.genero = "masculino";
	mulher.nome = "Maria Magdalena";
	mulher.genero = "feminino";
	
	//fazer as apresenta��es
	System.out.println("Ol�, meu nome � " + homem.apresentar () + ".");
	mulher.conhecer(homem.apresentar(),homem.genero);
	System.out.println("Eu sou " + mulher.apresentar () + ".");
	homem.conhecer (mulher.apresentar(),mulher.genero);

	}

}
