package br.com.encontro;

public class Pessoa {
//caracter�sticas
	public String nome;
	public String genero;
	// m�todos
public String apresentar() {
	return this.nome;
	
}

 //fun��o que recebe o nome e genero da outra pessoa que vai conhecer
public void conhecer (String nome, String genero) {
	//verifica o genero da outra pessoa
	if (genero == "masculino")
		System.out.println("Muito prazer, senhor: " + nome + ".");
	else if (genero == "feminino")
			System.out.println("Muito prazer, senhora: " + nome + ".");
	else
		System.out.println("Perd�o, n�o consigo saber quem �.");
}
	
		
			
}

