	package br.com.contauml;

import java.util.Scanner;

public class Conta {

	private String agencia;

	private static String numeroConta;

	private String cpfTitular;

	private static double saldo;

	

	public int OperacaoTipo;

	

	//m�todos
	

	
	public void fazerDeposito(double dinheiro) {
	
		saldo += dinheiro;
        System.out.println("Depositado: " + dinheiro);
        System.out.println("Novo saldo: " + saldo + "\n");
	}

	public double fazerSaque(double dinheiro) {
		 if(saldo >= dinheiro){
	            saldo -= dinheiro;
	            dinheiro++;
	            System.out.println("Sacado: " + dinheiro);
	            System.out.println("Novo saldo: " + saldo + "\n");
	        } else {
	            System.out.println("Saldo insuficiente. Fa�a um dep�sito\n");
	        }
		return dinheiro;
	}


public double consultarSaldo() {
	
		
		return 2000;
	}
			
			
				
		

	public void Dados () {
		
		System.out.println("Agencia:  "+ this.agencia);
		System.out.println("Conta:  "+ this.numeroConta);
		System.out.println("CPF do titular:  "+ this.getCpfTitular());
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public static String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public static double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public int getOperacaoTipo() {
		return OperacaoTipo;
	}

	public void setOperacaoTipo(int operacaoTipo) {
		this.OperacaoTipo = operacaoTipo;
	}

	public String getCpfTitular() {
		return cpfTitular;
	}

	public void setCpfTitular(String cpfTitular) {
		this.cpfTitular = cpfTitular;
	
	
	}

	public void consultarSaldo(double nextDouble) {
		// TODO Auto-generated method stub
		
	}
}
	
		
		

	
		

	
		
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		


			
	
