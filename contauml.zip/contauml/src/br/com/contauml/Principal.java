package br.com.contauml;

import java.util.Scanner;

import br.com.contauml.Conta;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// instancia objetos

				Scanner leia = new Scanner(System.in);
				Conta conta = new Conta();
			
			
				


				// entrada de dados
				
				System.out.println("Informe o CPF do titular da conta: ");
				conta.setCpfTitular(leia.nextLine());
				System.out.println("Informe o numero da conta:");
				conta.setNumeroConta(leia.nextLine());
				System.out.println("Informe o saldo");
				conta.setSaldo(leia.nextDouble());


				leia.nextLine();
		
				
				do {
				

		//escolha

				System.out.println("informe a opera��o a ser realizada:  ");
				System.out.println("1 - Exibir dados");
				System.out.println("2 - Consultar saldo");
				System.out.println("3 - Depositar");
				System.out.println("4 - Sacar");
				System.out.println("5 - Sair");
				conta.OperacaoTipo = leia.nextInt();
				

				switch (conta.OperacaoTipo) {
				case 1:
					
					break;
					
				case 2:
					
					System.out.println("Saldo:  " + conta.consultarSaldo());
					conta.consultarSaldo(leia.nextDouble());
					
					
					break;
					
				case 3:
					
					System.out.println("Informe o valor a ser depositado.");
					conta.fazerDeposito(leia.nextDouble());

					break;
					
				case 4:
					
					System.out.println("Informe o valor do saque: ");
					conta.fazerSaque(leia.nextDouble());
					break;
					
				case 5:
					
					System.out.println("obrigado pela prefer�ncia!");
					break;
					
				default:
					System.out.println("opera��o invalida!");
					break;
				}
				}while (conta.OperacaoTipo != 5);
				
				//saida de dados
			
				System.out.print("Conta: " +Conta.getNumeroConta() + ".");
				
				System.out.println("Saldo: " + Conta.getSaldo() + ".");
				
				
				System.out.println("Meu CPF � " + conta.getCpfTitular() + ".");
				
				conta.Dados();
				
		//fechar o objeto leia

				leia.close();

			}
		

	}


