package br.com.calculadora;
import java.util.Scanner;


public class Calculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double x,y;
double adicao, subtracao, multiplicacao, divisao;
int op;


Scanner entrada = new Scanner (System.in);


	System.out.println("Informe o valor de x: ");
x = entrada.nextDouble();
	System.out.println("Informe o valor de y: ");
	y = entrada.nextDouble();
	System.out.println("Escolha a opera��o:");
	System.out.println("[1] adi��o");
	System.out.println("[2] subtra��o");
	System.out.println("[3] multiplica��o");
	System.out.println("[4] divis�o");
	System.out.println("Digite a sua op��o:");
	op = entrada.nextInt();
	
	switch (op) {
		case 1:
			adicao = x+y;
			System.out.println(" O resultado �:"+adicao);
			break;
		
		case 2:
			subtracao = x-y;
			System.out.println(" O resultado �:"+subtracao);
			break;
		case 3:
			multiplicacao = x*y;
			System.out.println(" O resultado �:"+multiplicacao);
			break;
		case 4:
			divisao = x/y;
			System.out.println(" O resultado �:"+divisao);
			break;
			
			default:
				System.out.println(" opera��o n�o permitida!!!!");
			}
			
			
	}
	
	
	
	}




