package br.com.imc;
import java.util.Scanner;

public class IMC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner leitor = new Scanner(System.in);
System.out.println("Digite o peso: ");
double peso = leitor.nextDouble();
System.out.println("Digite a altura: ");
double altura = leitor.nextDouble();

double imc;
imc = peso/Math.pow(altura, 2);
System.out.println ("O IMC �: "+ imc);

}

}
