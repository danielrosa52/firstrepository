package br.com.cadastro_java;

// importa o JOptionPane
import javax.swing.JOptionPane;

// importa os pacotes
import br.com.cadastro_java.dao.*;
import br.com.cadastro_java.model.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// instancia os objetos
		Usuario usuario = new Usuario();
		UsuarioDAO cadastro = new UsuarioDAO();
		
		// declara��o de vari�veis
		Object acaoEscolha;
		Object alteracaoEscolha;
		Object desistirEscolha;
		
		// declara��o de arrays
		Object[] acaoOpcao = {"Cadastrar", "Pesquisar ID", "Sair"};
		Object[] alteracaoOpcao = {"Alterar nome", "Alterar e-mail", "Excluir", "Cancelar"};
		Object[] desistirOpcao = {"Sim", "N�o"};
		
		do {
			// janela de escolha de a��o do usu�rio
			acaoEscolha = JOptionPane.showInputDialog(null, "Escolha uma a��o:", "A��o", JOptionPane.QUESTION_MESSAGE, null, acaoOpcao, acaoOpcao[0]);
			
			if (acaoEscolha == "Cadastrar") {
				// input dos dados
				usuario.setNome(JOptionPane.showInputDialog("Informe o nome:"));
				usuario.setEmail(JOptionPane.showInputDialog("Informe o e-mail:"));
				
				// cadastra o usu�rio no banco
				cadastro.cadastrar(usuario);
				
				// informa o sucesso do cadastro
				JOptionPane.showMessageDialog(null, "Dados cadastrados com sucesso!");
				
			}
			else if (acaoEscolha == "Pesquisar ID") {
				// repassa o id para uma vari�vel string
				String id = JOptionPane.showInputDialog("Informe o ID a ser pesquisado:");
				
				// converte string para long
				Long idPesquisa = Long.parseLong(id);
				
				// repassa long para idUsuario
				usuario.setIdUsuario(idPesquisa);
				
				// repassa o objeto para o m�todo de pesquisa
				cadastro.pesquisarId(usuario);
				
				// exibe os dados na tela e armazena op��o na vari�vel
				alteracaoEscolha = JOptionPane.showInputDialog(null, "ID: " + usuario.getIdUsuario() + ".\nNome: " + usuario.getNome() + ".\nE-mail: " + usuario.getEmail() + ".", "Altera��o cadastral", JOptionPane.QUESTION_MESSAGE, null, alteracaoOpcao, alteracaoOpcao[0]);
				
				if (alteracaoEscolha == "Alterar nome") {
					// recebe o novo dado a ser alterado
					usuario.setNome(JOptionPane.showInputDialog("Informe o novo nome:"));
					
					// repassa os dados para o m�todo alterar
					cadastro.alterarNome(usuario);
					
					// exibe mensagem de sucesso
					JOptionPane.showMessageDialog(null, "Nome alterado com sucesso!");
					
				}
				else if (alteracaoEscolha == "Alterar e-mail") {
					// recebe o novo dado a ser alterado
					usuario.setEmail(JOptionPane.showInputDialog("Informe o novo e-mail:"));
					// repassa os dados para o m�todo alterar
					cadastro.alterarEmail(usuario);
					
					// exibe mensagem de sucesso
					JOptionPane.showMessageDialog(null, "E-mail alterado com sucesso!");
					
				}
				else if (alteracaoEscolha == "Excluir") {
					// pergunta se o usu�rio deseja excluir ou n�o
					desistirEscolha = JOptionPane.showInputDialog(null, "Tem certeza de que deseja excluir?", "Desistir", JOptionPane.QUESTION_MESSAGE, null, desistirOpcao, desistirOpcao[0]);
					
					if (desistirEscolha == "Sim") {
						// exclui o usu�rio selecionado
						cadastro.excluir(usuario);
						
						// mensagem de sucesso de exclus�o
						JOptionPane.showMessageDialog(null, "Usu�rio exclu�do com sucesso!");
						
						// limpa os dados do usu�rio
						usuario = null;
						
					}
					else {
						// mostra mensagem de opera��o cancelada
						JOptionPane.showMessageDialog(null, "Opera��o cancelada!");
						
					}
					
				}
				else {
					// mostra mensagem de opera��o cancelada
					JOptionPane.showMessageDialog(null, "Opera��o cancelada!");
					
				}
				
			}
			else {
				// informa que o programa se encerrou
				JOptionPane.showMessageDialog(null, "Aplica��o encerrada!");
				
				// encerra a aplica��o
				System.exit(0);
			}
			
		} while (acaoEscolha != "Sair");
		
	}

}
