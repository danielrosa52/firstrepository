package br.com.cadastro_java.interfaces;

// importa a classe Connection
import java.sql.Connection;

public interface ConexaoInterface {
	// m�todos a serem implementados
	public Connection ConexaoMySQL();
}
