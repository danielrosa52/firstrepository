package br.com.cadastro_java.interfaces;

// importa a classe Usuario
import br.com.cadastro_java.model.Usuario;

public interface UsuarioDAOInterface {
	// m�todo a ser implementado
	public void cadastrar(Usuario usuario);
	public void pesquisarId(Usuario usuario);
	public void alterarNome(Usuario usuario);
	public void alterarEmail(Usuario usuario);
	public void excluir(Usuario usuario);
}
