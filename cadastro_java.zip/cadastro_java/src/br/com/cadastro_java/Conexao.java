package br.com.cadastro_java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import br.com.cadastro_java.interfaces.ConexaoInterface;

public class Conexao implements ConexaoInterface {

	@Override
	public Connection ConexaoMySQL() {
		// TODO Auto-generated method stub
		try {
			// faz a conex�o com o banco atrav�s do driver
			return DriverManager.getConnection("jdbc:mysql://localhost/db_cadastro_java?" + "user=root&password=root");
		}
		catch(SQLException excecao) {
			// retorna mensagem de erro caso conex�o n�o seja realizada
			throw new RuntimeException(excecao);
		}
	}

}
