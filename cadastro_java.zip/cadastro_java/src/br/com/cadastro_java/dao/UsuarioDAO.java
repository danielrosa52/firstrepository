package br.com.cadastro_java.dao;

// importa a interface e a classe Usuario
import br.com.cadastro_java.interfaces.UsuarioDAOInterface;
import br.com.cadastro_java.model.Usuario;
import br.com.cadastro_java.Conexao;

// importa as classes da biblioteca do java
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO extends Usuario implements UsuarioDAOInterface {
	// atributos
	private Connection conn;
	
	public UsuarioDAO() {
		// TODO Auto-generated constructor stub
		this.conn = new Conexao().ConexaoMySQL();
	}

	@Override
	public void cadastrar(Usuario usuario) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO tb_usuario (nome,email) VALUES (?,?)";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa os valores para a consulta SQL
			stmt.setString(1, usuario.getNome());
			stmt.setString(2, usuario.getEmail());
			
			// executa a query
			stmt.execute();
			
			// fecha o objeto
			stmt.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void pesquisarId(Usuario usuario) {
		// repassando o c�digo SQL para a vari�vel
		String sql = "SELECT * FROM tb_usuario WHERE id_usuario = ?";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa os valores para a consulta SQL
			stmt.setLong(1, usuario.getIdUsuario());
			
			// executa a consulta SQL
			ResultSet resultado = stmt.executeQuery();
			
			// retorna o resultado e repassa para o objeto usuario
			while (resultado.next()) {
				usuario.setIdUsuario(resultado.getLong(1));
				usuario.setNome(resultado.getString(2));
				usuario.setEmail(resultado.getString(3));
			}
			
			// encerra os objetos
			resultado.close();
			stmt.close();
			
		}
		catch(SQLException e) {
			// retorna erro caso m�todo n�o seja executado
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void alterarNome(Usuario usuario) {
		// armazena a consulta
		String sql = "UPDATE tb_usuario SET nome = ? WHERE id_usuario = ?";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa os valores para a consulta sql
			stmt.setString(1, usuario.getNome());
			stmt.setLong(2, usuario.getIdUsuario());
			
			// executa a consutla sql
			stmt.execute();
			
			// fecha o objeto da consulta
			stmt.close();
		}
		catch(SQLException e) {
			// retorna erro caso m�todo n�o seja executado
			e.printStackTrace();
		}
	}
	
	@Override
	public void alterarEmail(Usuario usuario) {
		// armazena a consulta
		String sql = "UPDATE tb_usuario SET email = ? WHERE id_usuario = ?";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa os valores para a consulta sql
			stmt.setString(1, usuario.getEmail());
			stmt.setLong(2, usuario.getIdUsuario());
			
			// executa a consutla sql
			stmt.execute();
			
			// fecha o objeto da consulta
			stmt.close();
		}
		catch(SQLException e) {
			// retorna erro caso m�todo n�o seja executado
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void excluir(Usuario usuario) {
		// armazena a consulta
		String sql = "DELETE FROM tb_usuario WHERE id_usuario = ?";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa o valor para a consulta sql
			stmt.setLong(1, usuario.getIdUsuario());
			
			// executa o comando sql
			stmt.execute();
			
			// fecha o objeto stmt
			stmt.close();
		}
		catch(SQLException e) {
			// retorna erro caso m�todo n�o seja executado
			e.printStackTrace();
		}
		
	}

}
