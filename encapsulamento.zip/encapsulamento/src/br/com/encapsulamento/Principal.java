package br.com.encapsulamento;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//instancia os objetos
		PessoaFisica pessoa = new PessoaFisica();
		Scanner leia = new Scanner(System.in);
		
		//entrada de dados
		System.out.println("Informe o nome:");
		pessoa.setNome(leia.nextLine());
		System.out.println("Informe o RG:");
		pessoa.setRG(leia.nextLine());
		System.out.println("Informe o CPF:");
		pessoa.setCPF(leia.nextLine());
		System.out.println("Informe a profiss�o:");
		pessoa.setProfissao(leia.nextLine());
		System.out.println("Informe o endere�o:");
		pessoa.setEndereco(leia.nextLine());
		System.out.println("Informe o telefone:");
		pessoa.setTelefone(leia.nextLine());
		System.out.println("Informe o e-mail:");
		pessoa.setEmail(leia.nextLine());
		
		//sa�da de dados
		System.out.print("Ol�, meu nome � " + pessoa.getNome() + ".");
		System.out.println("Trabalho como " + pessoa.getProfissao() + ".");
		System.out.print("Meu RG � " + pessoa.getRG() + ".");
		System.out.println("Meu CPF � " + pessoa.getCPF() + ".");
		System.out.println("Endere�o: " + pessoa.getEndereco() + ".");
		System.out.println("Telefone: " + pessoa.getTelefone() + ".");
		System.out.println("E-mail: " + pessoa.getEmail() + ".");
		
		//fecha o objeto do tipo scanner
		leia.close();
	}

}
