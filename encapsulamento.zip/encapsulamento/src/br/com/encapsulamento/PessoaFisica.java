package br.com.encapsulamento;

public final class PessoaFisica extends Pessoa {
	//atributos
	private String nome;
	private String rg;
	private String cpf;
	private String profissao;
	
	//m�todos set
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void setRG(String rg) {
		this.rg = rg;
	}
	
	public void setCPF(String cpf) {
		this.cpf = cpf;
	}
	
	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}
	
	//m�todos get
	public String getNome() {
		return this.nome;
	}
	
	public String getRG() {
		return this.rg;
	}
	
	public String getCPF() {
		return this.cpf;
	}
	
	public String getProfissao() {
		return this.profissao;
	}
}
