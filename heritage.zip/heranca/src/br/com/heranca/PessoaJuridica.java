package br.com.heranca;

public class PessoaJuridica extends Pessoa {
	//atributos
	public String razaoSocial;
	public String nomeFantasia;
	public String cnpj;
	
	//m�todos
	public void fazerPropaganda(String nome, String profissao) {
		System.out.print("Ol�, meu nome � " + nome);
		System.out.print(". Trabalho como " + profissao);
		System.out.print(" na " + this.nomeFantasia + ", ");
		System.out.print(" de raz�o social " + this.razaoSocial);
		System.out.println(" e CNPJ " + this.cnpj + ".");
	}
}
