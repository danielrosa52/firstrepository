package br.com.heranca;

public class PessoaFisica extends Pessoa {
	//atributos
	public String nome;
	public String cpf;
	public String rg;
	public String genero;
	public String profissao;
	public double peso;
	public double altura;
	
	//m�todos
	public void apresentar() {
		System.out.println("Prazer, meu nome � " + this.nome + ".");
		System.out.println("Sou do g�nero " + this.genero + ".");
		System.out.println("Tenho " + this.altura + " de altura.");
		System.out.println("E peso " + this.peso + " kg.");
		System.out.println("Meu RG � " + this.rg + ".");
		System.out.println("Meu CPF � " + this.cpf + ".");
		System.out.println("Atualmente sou " + this.profissao + ".");
	}
}
