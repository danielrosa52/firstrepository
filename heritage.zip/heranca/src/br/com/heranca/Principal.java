package br.com.heranca;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instancia os objetos
		Scanner leia = new Scanner(System.in);
		PessoaFisica humano = new PessoaFisica();
		PessoaJuridica empresa = new PessoaJuridica();
		
		//entrada de dados da pessoa f�sica
		System.out.println("Informe seu nome: ");
		humano.nome = leia.nextLine();
		System.out.println("Informe o CPF:");
		humano.cpf = leia.nextLine();
		System.out.println("Informe o RG:");
		humano.rg = leia.nextLine();
		System.out.println("Informe o g�nero:");
		humano.genero = leia.nextLine();
		System.out.println("Informe o endere�o:");
		humano.endereco = leia.nextLine();
		System.out.println("Informe o telefone:");
		humano.telefone = leia.nextLine();
		System.out.println("Informe o e-mail:");
		humano.email = leia.nextLine();
		System.out.println("Informe a profiss�o:");
		humano.profissao = leia.nextLine();
		System.out.println("Informe o peso:");
		humano.peso = leia.nextDouble();
		System.out.println("Informe a altura:");
		humano.altura = leia.nextDouble();
		
		//limpeza de buffer
		leia.nextLine();
		
		//entrada de dados da pessoa jur�dica
		System.out.println("Informe a raz�o social da empresa:");
		empresa.razaoSocial = leia.nextLine();
		System.out.println("Informe o nome fantasia da empresa:");
		empresa.nomeFantasia = leia.nextLine();
		System.out.println("Informe o CNPJ da empresa:");
		empresa.cnpj = leia.nextLine();
		System.out.println("Informe o endere�o:");
		empresa.endereco = leia.nextLine();
		System.out.println("Informe o telefone da empresa:");
		empresa.telefone = leia.nextLine();
		System.out.println("Informe o e-mail da empresa:");
		empresa.email = leia.nextLine();
		
		//sa�da de dados
		humano.apresentar();
		humano.mostrarContatos();
		empresa.fazerPropaganda(humano.nome, humano.profissao);
		empresa.mostrarContatos();
		
		//fecha o objeto leia
		leia.close();
	}

}
