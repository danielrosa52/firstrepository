package br.com.heranca;

public class Pessoa {
	//atributos
	public String endereco;
	public String telefone;
	public String email;
	
	//m�todos
	public void mostrarContatos() {
		System.out.println("Meus contatos:");
		System.out.println("Endere�o: " + this.endereco + ".");
		System.out.println("Meu telefone � " + this.telefone + ".");
		System.out.println("Meu e-mail � " + this.email + ".");
	}
}
