package br.com.contapane;
import javax.swing.JOptionPane;


public class Principal {

	public static void main(String[] args) {
		// declara��o de vari�veis
		String valor;
		Object escolha;
		
		// Criando a array
		Object[]opcoes= {"saldo", "deposito", "saque", "sair"};
		
		// instanciando objetos
		
		ContaPane contapane = new ContaPane();
		
		// entrando com os atributos do objeto
		contapane.setAgencia("10001-1");
		contapane.setNumerodaconta("00001-1");
		contapane.setCpfTitular(JOptionPane.showInputDialog("informe o cpf do titular: "));
		contapane.setSaldo(0);
		
		//Criando la�o de repeti��o
		do {
			
		
		
		//mostrando dados da conta e opera��es
		
		escolha= JOptionPane.showInputDialog(
				null, 
						 "\n Ag�ncia: "+contapane.getAgencia() +
						"\n N�mero da conta: "+
							contapane.getNumerodaconta()+
						"\n cpf do titular:"+contapane.getCpfTitular()+
						"\n escolha a opera��o:", 
						
						"Opera��es",
						JOptionPane.QUESTION_MESSAGE,
						null,
		
		opcoes,
		opcoes[0]);
									// Verificacando a opera��o escolhida
		if (escolha == "saldo") {
			JOptionPane.showMessageDialog(null, "saldo: R$ "+ contapane.getSaldo());
		}
		else if (escolha == "deposito") {
			valor=JOptionPane.showInputDialog("informe o valor do dep�sito: ");
			contapane.fazerDeposito(Double.parseDouble(valor));
			JOptionPane.showInternalMessageDialog(null, "opera��o realizada com sucesso!");
		}
		else if (escolha == "saque") {
			valor=JOptionPane.showInputDialog(null, "informe o valor do saque:");
			if (Double.parseDouble(valor)<=contapane.getSaldo()) {
				contapane.fazerSaque(Double.parseDouble(valor));
				JOptionPane.showMessageDialog(null, "opera��o realizada com sucesso!");
				
			} else
				JOptionPane.showInternalMessageDialog(null, "Saldo insuficiente!");
		}
			else { 
				JOptionPane.showInternalMessageDialog(null, "Sess�o encerrada. Muito Obrigado!");
				System.exit(0);
			}
	
	}while (escolha !="sair");
	}
}




	
