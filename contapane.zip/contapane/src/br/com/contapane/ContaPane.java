package br.com.contapane;

public class ContaPane {

	//atributos
	
	private String agencia;
	private String numerodaconta;
	private String cpfTitular;
	private double saldo;
	
	//m�todos
	public double fazerDeposito (double dinheiro) {
		return this.saldo= this.saldo + dinheiro;
		
	}
	public double fazerSaque(double dinheiro) {
		
		if(this.saldo>0 && this.saldo>=dinheiro)
			return this.saldo=this.saldo - dinheiro;
		else
			return 0;
		
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getNumerodaconta() {
		return numerodaconta;
	}
	public void setNumerodaconta(String numerodaconta) {
		this.numerodaconta = numerodaconta;
	}
	public String getCpfTitular() {
		return cpfTitular;
	}
	public void setCpfTitular(String cpfTitular) {
		this.cpfTitular = cpfTitular;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
}