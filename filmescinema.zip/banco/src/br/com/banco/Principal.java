package br.com.banco;

import java.util.Random;
import java.util.Scanner;

import br.com.banco.Conta;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  // Declarando as vari�veis, Scanner e Random
		
	       String nome;
	       double inicial;
	   String cpf;
	        Scanner entrada = new Scanner(System.in);
	        Random numero = new Random();
	        int conta = 1 + numero.nextInt(9999);
	    
	        //Obtendo os dados iniciais do Cliente
	        
	        
	        System.out.print("Entre com seu nome: ");
	        nome = entrada.nextLine();
	        System.out.println("Informe seu cpf");
	        cpf = entrada.nextLine ();
	        
	        
	        
	        System.out.print("Entre com o valor inicial depositado na conta: ");
	        inicial = entrada.nextDouble();
	        
	        //Criando a conta de um cliente
	        
	        Conta minhaConta = new Conta(nome, conta, inicial);
	        minhaConta.iniciar();
	    }
	    
	}
